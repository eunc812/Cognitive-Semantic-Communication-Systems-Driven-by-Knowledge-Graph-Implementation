#!/usr/bin/env python
"""Reproduces the original Colab notebook as a single Python script.

This is intentionally "not pretty": it's a faithful, linear reproduction.
For cleaner usage, import functions from `kg_semcom.*` and write your own driver.
"""

import argparse

from kg_semcom.preprocess import *  # noqa
from kg_semcom.channel import *     # noqa
from kg_semcom.coding import *      # noqa
from kg_semcom.kg2text import *     # noqa
from kg_semcom.metrics import *     # noqa
from kg_semcom.experiments import * # noqa

def main():
    import os, json, random, re, math
    from collections import Counter, defaultdict
    import numpy as np
    
    BASE_DIR = args.base_dir
    os.makedirs(BASE_DIR, exist_ok=True)
    
    OUT_PAIRS   = os.path.join(BASE_DIR, "pairs_train_10016.json")
    OUT_ALIGNED = os.path.join(BASE_DIR, "text2kg_aligned_train_10016.json")
    OUT_SSC     = os.path.join(BASE_DIR, "kg_triples_ssc_train_10016.json")
    
    SEED = 42
    random.seed(SEED)
    
    # ---------- load WebNLG (Orange/webnlg-qa가 너 환경에서 이미 동작했었음) ----------
    from datasets import load_dataset
    ds = load_dataset("Orange/webnlg-qa", split="train")   # rows=10016
    print("rows:", len(ds))
    print("keys:", ds.column_names)
    
    
    
    pairs=[]
    for i in range(len(ds)):
        row = ds[i]
        text = pick_text(row)
        triples = pick_triples(row)
        if text.strip() and len(triples)>0:
            pairs.append({"idx": int(row.get("id", i)), "text": text, "triples": triples})
    
    print("pairs:", len(pairs))
    with open(OUT_PAIRS, "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=2)
    print("saved:", OUT_PAIRS)
    
    # ---------- Text2KG alignment (Table I 스타일) ----------
    
    
    
    aligned=[]
    for ex in pairs:
        at = align_triples_by_contains(ex["text"], ex["triples"])
        aligned.append({"idx": ex["idx"], "aligned_triples": at, "gold_triples": ex["triples"]})
    
    with open(OUT_ALIGNED, "w", encoding="utf-8") as f:
        json.dump(aligned, f, ensure_ascii=False, indent=2)
    print("saved:", OUT_ALIGNED)
    
    # ---------- SSC (dictionary + fixed-length binary) ----------
    # 1) vocab 만들기
    ents=set()
    rels=set()
    all_triples=[]
    for ex in pairs:
        for h,r,t in ex["triples"]:
            ents.add(_strip_uri_datatype(h))
            ents.add(_strip_uri_datatype(t))
            rels.add(str(r))
            all_triples.append([h,r,t])
    
    ent2id = {e:i for i,e in enumerate(sorted(ents))}
    rel2id = {r:i for i,r in enumerate(sorted(rels))}
    # triple code length bits
    B_ent = int(math.ceil(math.log2(len(ent2id)+1)))
    B_rel = int(math.ceil(math.log2(len(rel2id)+1)))
    L = B_ent + B_rel + B_ent
    print("vocab ents:", len(ent2id), "rels:", len(rel2id))
    print("bits:", "B_ent", B_ent, "B_rel", B_rel, "L", L)
    
    
    
    # unique triples만 SSC에 저장
    seen=set()
    ssc=[]
    for h,r,t in all_triples:
        key=(h,r,t)
        if key in seen:
            continue
        seen.add(key)
        ssc.append({"triple":[h,r,t], "bits": triple_to_bits([h,r,t])})
    
    with open(OUT_SSC, "w", encoding="utf-8") as f:
        json.dump(ssc, f, ensure_ascii=False, indent=2)
    print("unique triples:", len(ssc))
    print("saved:", OUT_SSC)
    
    
    import os, json, re
    from collections import defaultdict
    from tqdm import tqdm
    
    KG_PATH    = "/content/webnlg_kg_text2kg_1000/kg_triples_ssc_train_10016.json"
    PAIRS_PATH = "/content/webnlg_kg_text2kg_1000/pairs_train_10016.json"
    OUT_PATH   = "/content/webnlg_kg_text2kg_1000/semantic_symbol_abstraction_train_10016.json"
    
    assert os.path.exists(KG_PATH), KG_PATH
    assert os.path.exists(PAIRS_PATH), PAIRS_PATH
    
    with open(KG_PATH, "r", encoding="utf-8") as f:
        kg_triples = json.load(f)   # each: {"triple":[h,r,t], "bits":[...]}
    with open(PAIRS_PATH, "r", encoding="utf-8") as f:
        pairs = json.load(f)        # each: {"idx":..., "text":..., "triples":[...]}
    
    print("KG:", KG_PATH)
    print("Pairs:", PAIRS_PATH)
    print("KG triples:", len(kg_triples))
    print("Pairs:", len(pairs))
    
    # -------------------------
    # Normalization (match-friendly)
    # -------------------------
    
    
    # -------------------------
    # Build head index
    # -------------------------
    head_index = defaultdict(list)
    
    # ✅ FIX: tr["h"]가 아니라 tr["triple"][0]을 head로
    for tr in kg_triples:
        if "triple" not in tr or not isinstance(tr["triple"], list) or len(tr["triple"]) < 3:
            continue
        h, r, t = tr["triple"][0], tr["triple"][1], tr["triple"][2]
        head_index[norm(h)].append(tr)
    
    all_heads = list(head_index.keys())
    print("Unique heads indexed:", len(all_heads))
    
    # -------------------------
    # Text2KG-style alignment (Table I)
    # - for each sentence s
    # - for each triple(h,r,t) in KG
    #   if s contains h and s contains t => select
    #
    # But brute force is huge, so we:
    #  1) find which KG heads appear in s (via simple scan)
    #  2) only test triples under those heads
    # -------------------------
    
    results = []
    skipped_no_head = 0
    
    # heads가 너무 많으면 포함 체크가 느릴 수 있어서
    # head 길이가 짧은 것들(예: 1~2글자)은 오탐 많아 제외하는 옵션
    MIN_HEAD_LEN = 3
    
    heads_filtered = [h for h in all_heads if len(h) >= MIN_HEAD_LEN]
    
    for ex in tqdm(pairs, total=len(pairs)):
        idx = ex.get("idx")
        text = ex.get("text", "")
        s_norm = norm(text)
    
        cand_heads = find_candidate_heads_in_text(s_norm, heads_filtered)
        if not cand_heads:
            skipped_no_head += 1
            results.append({
                "idx": idx,
                "text": text,
                "semantic_symbols": [],   # aligned triples (KG 기준)
            })
            continue
    
        aligned = []
        for h in cand_heads:
            for tr in head_index[h]:
                hh, rr, tt = tr["triple"]
                # Table I 조건: s.contains(h) AND s.contains(t)
                if norm(tt) in s_norm:
                    aligned.append({
                        "triple": tr["triple"],
                        "bits": tr["bits"]
                    })
    
        results.append({
            "idx": idx,
            "text": text,
            "semantic_symbols": aligned
        })
    
    print("Skipped (no head found):", skipped_no_head, "/", len(pairs))
    
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print("Saved:", OUT_PATH)
    
    # quick sanity check
    nonempty = sum(1 for x in results if len(x["semantic_symbols"]) > 0)
    print("Non-empty semantic symbols:", nonempty, "/", len(results))
    print("Example non-empty:")
    for x in results:
        if x["semantic_symbols"]:
            print("idx:", x["idx"])
            print("text:", x["text"][:160])
            print("first symbol:", x["semantic_symbols"][0]["triple"])
            break
    
    
    import os, json, math, re
    from collections import defaultdict
    from tqdm import tqdm
    
    BASE_DIR = args.base_dir
    
    # ✅ 너가 지금 만든 10k(train=10016) 파일들
    KG_SSC_PATH = os.path.join(BASE_DIR, "kg_triples_ssc_train_10016.json")
    B_OUT_PATH  = os.path.join(BASE_DIR, "semantic_symbol_abstraction_train_10016.json")
    
    assert os.path.exists(KG_SSC_PATH), f"Missing: {KG_SSC_PATH}"
    assert os.path.exists(B_OUT_PATH),  f"Missing: {B_OUT_PATH}"
    
    with open(KG_SSC_PATH, "r", encoding="utf-8") as f:
        kg_ssc = json.load(f)  # each: {"triple":[h,r,t], "bits":[...]}
    with open(B_OUT_PATH, "r", encoding="utf-8") as f:
        abstr = json.load(f)   # each: {"idx","text","semantic_symbols":[{"triple":[...],"bits":[...]}]}
    
    print("KG:", KG_SSC_PATH)
    print("B out:", B_OUT_PATH)
    print("KG triples:", len(kg_ssc))
    print("B items:", len(abstr))
    
    # -------------------------
    # normalize (dictionary key 안정화용)
    # -------------------------
    
    
    
    # -------------------------
    # 1) Build dictionaries: entity2id, rel2id
    # -------------------------
    entities=set()
    relations=set()
    
    for it in kg_ssc:
        tri = it.get("triple", None)
        if not tri or len(tri) < 3:
            continue
        h,r,t = tri[0], tri[1], tri[2]
        entities.add(strip_datatype(h))
        entities.add(strip_datatype(t))
        relations.add(str(r))
    
    entities = sorted(list(entities))
    relations = sorted(list(relations))
    
    entity2id = {e:i for i,e in enumerate(entities)}
    rel2id    = {r:i for i,r in enumerate(relations)}
    
    print("Num entities:", len(entity2id))
    print("Num relations:", len(rel2id))
    
    # bit-length (fixed)
    bE = math.ceil(math.log2(len(entity2id))) if len(entity2id) > 1 else 1
    bR = math.ceil(math.log2(len(rel2id))) if len(rel2id) > 1 else 1
    print("Bits per entity:", bE, "| Bits per relation:", bR, "| Total bits per triple:", 2*bE + bR)
    
    # save dicts
    with open(os.path.join(BASE_DIR, "entity2id_train_10016.json"), "w", encoding="utf-8") as f:
        json.dump(entity2id, f, ensure_ascii=False, indent=2)
    with open(os.path.join(BASE_DIR, "rel2id_train_10016.json"), "w", encoding="utf-8") as f:
        json.dump(rel2id, f, ensure_ascii=False, indent=2)
    
    print("Saved dictionaries:",
          os.path.join(BASE_DIR, "entity2id_train_10016.json"),
          os.path.join(BASE_DIR, "rel2id_train_10016.json"))
    
    # -------------------------
    # 2) Attach integer ids to KG SSC
    #    (bits는 기존 파일 것을 그대로 사용)
    # -------------------------
    
    kg_ssc_with_ids = []
    # lookup: norm triple -> (bits, raw triple)
    kg_lookup = {}
    for it in kg_ssc:
        tri = it["triple"]
        key = norm_triple_key(tri)
        kg_lookup[key] = {"bits": it["bits"], "triple": tri}
    
    for it in kg_ssc:
        tri = it["triple"]
        hid, rid, tid = triple_to_ids(tri)
        kg_ssc_with_ids.append({
            "triple": tri,
            "hid": hid, "rid": rid, "tid": tid,
            "bits": it["bits"]
        })
    
    OUT_KG_SSC_IDS = os.path.join(BASE_DIR, "kg_triples_ssc_with_ids_train_10016.json")
    with open(OUT_KG_SSC_IDS, "w", encoding="utf-8") as f:
        json.dump(kg_ssc_with_ids, f, ensure_ascii=False, indent=2)
    
    print("Saved:", OUT_KG_SSC_IDS)
    
    # -------------------------
    # 3) Attach ids (and fill missing bits) to B output
    # -------------------------
    fixed = 0
    missing = 0
    
    for ex in abstr:
        new_syms=[]
        for sym in ex.get("semantic_symbols", []):
            tri = sym.get("triple", None)
            if not tri or len(tri) < 3:
                continue
    
            # bits가 없으면 KG에서 채워줌
            bits = sym.get("bits", None)
            if bits is None:
                key = norm_triple_key(tri)
                if key in kg_lookup:
                    bits = kg_lookup[key]["bits"]
                    fixed += 1
                else:
                    missing += 1
                    continue
    
            hid, rid, tid = triple_to_ids(tri)
            new_syms.append({
                "triple": tri,
                "hid": hid, "rid": rid, "tid": tid,
                "bits": bits
            })
        ex["semantic_symbols_ssc"] = new_syms
    
    OUT_ABSTR_SSC = os.path.join(BASE_DIR, "semantic_symbol_abstraction_ssc_train_10016.json")
    with open(OUT_ABSTR_SSC, "w", encoding="utf-8") as f:
        json.dump(abstr, f, ensure_ascii=False, indent=2)
    
    print("Saved:", OUT_ABSTR_SSC)
    print("Filled missing bits from KG:", fixed)
    print("Missing triples not found in KG:", missing)
    
    # sanity
    for ex in abstr:
        if ex.get("semantic_symbols_ssc"):
            print("\n--- SANITY ---")
            print("idx:", ex.get("idx"))
            print("text:", ex.get("text","")[:120])
            print("first symbol:", ex["semantic_symbols_ssc"][0])
            break
    
    
    import os, json, numpy as np
    from tqdm import tqdm
    
    BASE_DIR = args.base_dir
    
    ABSTR_SSC_PATH   = os.path.join(BASE_DIR, "semantic_symbol_abstraction_ssc_train_10016.json")
    KG_SSC_IDS_PATH  = os.path.join(BASE_DIR, "kg_triples_ssc_with_ids_train_10016.json")
    
    assert os.path.exists(ABSTR_SSC_PATH), ABSTR_SSC_PATH
    assert os.path.exists(KG_SSC_IDS_PATH), KG_SSC_IDS_PATH
    
    with open(ABSTR_SSC_PATH, "r", encoding="utf-8") as f:
        abstr = json.load(f)   # each: {"idx","text",...,"semantic_symbols_ssc":[{triple,hid,rid,tid,bits}]}
    with open(KG_SSC_IDS_PATH, "r", encoding="utf-8") as f:
        kg = json.load(f)      # each: {"triple":[h,r,t], "hid","rid","tid","bits"}
    
    L = len(kg[0]["bits"])
    print("Loaded abstr:", len(abstr))
    print("Loaded KG:", len(kg))
    print("SSC bits length L:", L)
    
    # -------------------------
    # D parameters
    # -------------------------
    P = 0.10         # BSC error prob (원하면 0.0~0.2로 바꿔)
    REP = 3          # repetition code
    OUT_PATH = os.path.join(BASE_DIR, f"channel_decoded_symbols_train_10016_p{int(P*100):02d}_rep{REP}.json")
    
    # -------------------------
    # Channel coding / channel / decoding
    # -------------------------
    
    
    
    # -------------------------
    # Build KG codebook arrays for correction
    # -------------------------
    KG_BITS = np.array([it["bits"] for it in kg], dtype=np.int8)
    
    # bits -> triple/ids 역매핑 (bits는 list라 tuple로)
    bits2meta = {}
    for it in kg:
        bits2meta[tuple(it["bits"])] = {
            "triple": it["triple"],
            "hid": it["hid"], "rid": it["rid"], "tid": it["tid"],
            "bits": it["bits"]
        }
    
    
    # -------------------------
    # Run over dataset (D)
    # -------------------------
    out = []
    empty_in = 0
    empty_out = 0
    
    for ex in tqdm(abstr, total=len(abstr)):
        syms = ex.get("semantic_symbols_ssc", [])
        if not syms:
            empty_in += 1
            out.append({
                "idx": ex.get("idx"),
                "text": ex.get("text"),
                "decoded_symbols": []
            })
            continue
    
        decoded = []
        for s in syms:
            b = np.array(s["bits"], dtype=np.int8)
            tx = rep_encode(b, rep=REP)
            rx = bsc(tx, P)
            o  = rep_decode(rx, rep=REP)
    
            meta = correction(o)  # corrected symbol from KG
            decoded.append(meta)
    
        if not decoded:
            empty_out += 1
    
        out.append({
            "idx": ex.get("idx"),
            "text": ex.get("text"),
            "decoded_symbols": decoded
        })
    
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    
    print("\nSaved:", OUT_PATH)
    print("Empty input (no symbols):", empty_in, "/", len(abstr))
    print("Empty output (after decode):", empty_out, "/", len(abstr))
    
    # -------------------------
    # Demo print (1 example)
    # -------------------------
    for ex in out:
        if ex["decoded_symbols"]:
            print("\n==== DEMO (D output) ====")
            print("idx:", ex["idx"])
            print("text:", (ex["text"] or "")[:200])
            print("decoded_symbols count:", len(ex["decoded_symbols"]))
            print("first decoded triple:", ex["decoded_symbols"][0]["triple"])
            print("first decoded ids:", (ex["decoded_symbols"][0]["hid"], ex["decoded_symbols"][0]["rid"], ex["decoded_symbols"][0]["tid"]))
            break
    
    
    # ✅ torch는 건드리지 말고, transformers 쪽만 맞춰 설치
    
    
    import os, json, random, re, math
    from collections import Counter
    from typing import List, Dict
    
    import torch
    from torch.utils.data import Dataset, DataLoader
    from tqdm import tqdm
    
    from transformers import T5TokenizerFast, T5ForConditionalGeneration
    
    # -----------------------
    # Config
    # -----------------------
    BASE_DIR = args.base_dir
    PAIR_PATH = os.path.join(BASE_DIR, "pairs_train_10016.json")
    assert os.path.exists(PAIR_PATH), f"Missing {PAIR_PATH}"
    
    MODEL_NAME = "t5-small"
    OUT_DIR = os.path.join(BASE_DIR, "t5_kg2text_pt")
    os.makedirs(OUT_DIR, exist_ok=True)
    
    SEED = 42
    random.seed(SEED)
    torch.manual_seed(SEED)
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device)
    
    MAX_SRC_LEN = 256
    MAX_TGT_LEN = 128
    BATCH_SIZE  = 8
    EPOCHS      = 10        # 먼저 1~2 epoch 추천 (원하면 5~10으로)
    LR          = 3e-4
    GRAD_CLIP   = 1.0
    
    # -----------------------
    # Load pairs (train=10016)
    # -----------------------
    with open(PAIR_PATH, "r", encoding="utf-8") as f:
        pairs = json.load(f)
    
    print("Loaded pairs:", len(pairs))
    print("Example text:", pairs[0]["text"][:120])
    print("Example triples:", pairs[0]["triples"][:3])
    
    random.shuffle(pairs)
    n_train = int(len(pairs) * 0.95)
    train_pairs = pairs[:n_train]
    val_pairs   = pairs[n_train:]
    print("train:", len(train_pairs), "val:", len(val_pairs))
    
    # -----------------------
    # Linearize triples (논문 입력 스타일)
    # "head relation1 tail1, relation2 tail2, ..."
    # -----------------------
    
    
    # -----------------------
    # Dataset / Collate
    # -----------------------
    tokenizer = T5TokenizerFast.from_pretrained(MODEL_NAME)
    
    
    
    train_loader = DataLoader(KG2TextDataset(train_pairs), batch_size=BATCH_SIZE, shuffle=True, collate_fn=collate_fn)
    val_loader   = DataLoader(KG2TextDataset(val_pairs),   batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)
    
    # -----------------------
    # Model / Optim
    # -----------------------
    model = T5ForConditionalGeneration.from_pretrained(MODEL_NAME).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)
    
    # -----------------------
    # Eval
    # -----------------------
    @torch.no_grad()
    
    # -----------------------
    # Train
    # -----------------------
    print("\nStarting fine-tuning...")
    for epoch in range(1, EPOCHS+1):
        model.train()
        pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{EPOCHS}")
        running, seen = 0.0, 0
    
        for batch in pbar:
            batch = {k:v.to(device) for k,v in batch.items()}
            out = model(**batch)
            loss = out.loss
    
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
            optimizer.step()
    
            bs = batch["input_ids"].size(0)
            running += loss.item() * bs
            seen += bs
            pbar.set_postfix(train_loss=running/max(seen,1))
    
        v = eval_loss()
        print(f"Epoch {epoch} done | train_loss={running/max(seen,1):.4f} | val_loss={v:.4f}")
    
    # -----------------------
    # Save
    # -----------------------
    model.save_pretrained(OUT_DIR)
    tokenizer.save_pretrained(OUT_DIR)
    print("Saved fine-tuned model to:", OUT_DIR)
    
    # -----------------------
    # Quick demo
    # -----------------------
    @torch.no_grad()
    
    demo = val_pairs[0]
    src, out = gen_one(demo["triples"])
    print("\n====== DEMO (Fine-tuned) ======")
    print("INPUT:", src[:220])
    print("GOLD :", demo["text"][:220])
    print("GEN  :", out[:220])
    
    
    # torch는 건드리지 말기
    
    import os, json, random, re
    from collections import Counter
    from typing import List
    
    import torch
    from transformers import T5TokenizerFast, T5ForConditionalGeneration
    import evaluate
    
    BASE_DIR  = "/content/webnlg_kg_text2kg_1000"
    PAIR_PATH = os.path.join(BASE_DIR, "pairs_train_10016.json")   # ✅ 10016 버전
    MODEL_DIR = os.path.join(BASE_DIR, "t5_kg2text_pt")            # ✅ 방금 저장한 모델
    
    assert os.path.exists(PAIR_PATH), f"Missing {PAIR_PATH}"
    assert os.path.exists(MODEL_DIR), f"Missing {MODEL_DIR} (파인튜닝 저장 경로 확인)"
    
    # -----------------------
    # Load data
    # -----------------------
    with open(PAIR_PATH, "r", encoding="utf-8") as f:
        pairs = json.load(f)
    
    random.seed(42)
    random.shuffle(pairs)
    n_train = int(len(pairs) * 0.95)   # 학습 셀과 동일하게 95/5로 분할
    train_pairs = pairs[:n_train]
    val_pairs   = pairs[n_train:]
    
    print("train:", len(train_pairs), "val:", len(val_pairs))
    
    # -----------------------
    # Same linearize function used in training (중요!)
    # (논문 스타일: head relation1 tail1, relation2 tail2, ...)
    # -----------------------
    
    
    # -----------------------
    # Load finetuned model
    # -----------------------
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = T5TokenizerFast.from_pretrained(MODEL_DIR)
    model = T5ForConditionalGeneration.from_pretrained(MODEL_DIR).to(device)
    model.eval()
    print("device:", device)
    
    MAX_SRC_LEN = 256
    
    
    # -----------------------
    # 1) Qualitative: N samples show GOLD vs GEN
    # -----------------------
    N_SHOW = 10
    samples = random.sample(val_pairs, min(N_SHOW, len(val_pairs)))
    
    print("\n================= QUALITATIVE COMPARISON =================")
    for i, ex in enumerate(samples, 1):
        src, gen = generate_text(ex["triples"])
        gold = ex["text"]
    
        print(f"\n--- Sample {i} ---")
        print("INPUT:", src)
        print("GOLD :", gold)
        print("GEN  :", gen)
    
    # -----------------------
    # 2) Quantitative: BLEU / ROUGE-L (subset)
    # -----------------------
    N_EVAL = 200   # 100~500 추천
    eval_set = random.sample(val_pairs, min(N_EVAL, len(val_pairs)))
    
    preds = []
    refs  = []
    for ex in eval_set:
        _, gen = generate_text(ex["triples"], num_beams=1, max_new_tokens=80)  # 평가 속도 위해 beam=1 추천
        preds.append(gen)
        refs.append(ex["text"])
    
    bleu  = evaluate.load("sacrebleu")
    rouge = evaluate.load("rouge")
    
    bleu_score  = bleu.compute(predictions=preds, references=[[r] for r in refs])["score"]
    rouge_score = rouge.compute(predictions=preds, references=refs)["rougeL"]
    
    print("\n================= QUICK METRICS =================")
    print(f"Eval samples: {len(eval_set)}")
    print(f"BLEU (sacreBLEU): {bleu_score:.2f}")
    print(f"ROUGE-L        : {rouge_score:.4f}")
    
    
    import os, json, math, re
    from collections import Counter
    import numpy as np
    import matplotlib.pyplot as plt
    
    BASE_DIR = args.base_dir
    
    PAIRS_PATH = os.path.join(BASE_DIR, "pairs_train_10016.json")
    # ✅ B/C 결과: 문장별 semantic symbol 개수(=보내는 triple 수)를 여기서 읽음
    ABSTR_SSC_PATH = os.path.join(BASE_DIR, "semantic_symbol_abstraction_ssc_train_10016.json")
    # ✅ L(SSC bits/triple) 얻기 위한 KG SSC
    KG_SSC_PATH = os.path.join(BASE_DIR, "kg_triples_ssc_train_10016.json")
    
    assert os.path.exists(PAIRS_PATH), PAIRS_PATH
    assert os.path.exists(ABSTR_SSC_PATH), ABSTR_SSC_PATH
    assert os.path.exists(KG_SSC_PATH), KG_SSC_PATH
    
    # ----------------------------
    # Config
    # ----------------------------
    REP = 3  # repetition BCC (rep=3이면 3배 전송)
    USE_UNICODE_BYTES_FOR_BIT7 = False
    
    # ----------------------------
    # Load data
    # ----------------------------
    with open(PAIRS_PATH, "r", encoding="utf-8") as f:
        pairs = json.load(f)
    
    with open(ABSTR_SSC_PATH, "r", encoding="utf-8") as f:
        abstr = json.load(f)
    
    with open(KG_SSC_PATH, "r", encoding="utf-8") as f:
        kg_ssc = json.load(f)
    
    # idx 매핑 (int로 통일)
    
    pairs_by_idx = {to_int_idx(ex.get("idx", i)): ex for i, ex in enumerate(pairs)}
    abstr_by_idx = {to_int_idx(ex.get("idx")): ex for ex in abstr if "idx" in ex}
    
    # SSC bit length L (triple당 비트 수)
    L = len(kg_ssc[0]["bits"])
    print("SSC bits per triple L =", L)
    print("pairs:", len(pairs), "abstr:", len(abstr))
    
    # ----------------------------
    # Huffman coding utilities (character-level)
    # ----------------------------
    
    
    # 코퍼스 기반 Huffman codebook 생성
    all_text = "".join([ex["text"] for ex in pairs])
    freq = Counter(all_text)
    huff_len = build_huffman_code_lengths(freq)
    
    
    
    
    # ----------------------------
    # Compute per-sample bits
    # ----------------------------
    rows = []
    for ex in pairs:
        idx = to_int_idx(ex.get("idx"))
        text = ex["text"]
        n_chars = len(text)
    
        b_bit7  = bit7_bits(text)
        b_huff  = huffman_bits(text)
        b_ours  = ours_bits_from_abstr(idx)
    
        rows.append({
            "idx": idx,
            "chars": n_chars,
            "bit7_bcc": b_bit7 * REP,
            "huff_bcc": b_huff * REP,
            "ours_bcc": b_ours * REP,  # ours도 동일 BCC 적용 (공정 비교)
        })
    
    print("Computed rows:", len(rows))
    
    # ----------------------------
    # Figure 4: bits vs sentence length (char bins)
    # ----------------------------
    bins = [(0,100), (100,200), (200,300), (300,400), (400,10**9)]
    bin_labels = ["0-100","100-200","200-300","300-400","400+"]
    
    
    y_huff = avg_in_bin("huff_bcc")
    y_bit7 = avg_in_bin("bit7_bcc")
    y_ours = avg_in_bin("ours_bcc")
    
    plt.figure(figsize=(7,4.5))
    x = np.arange(len(bin_labels))
    plt.plot(x, y_huff, marker="o", label="Huffman + BCC")
    plt.plot(x, y_bit7, marker="^", label="Bit7 + BCC")
    plt.plot(x, y_ours, marker="*", label="Our proposed cognitive SC")
    plt.xticks(x, bin_labels)
    plt.xlabel("Sentence length (char)")
    plt.ylabel("Number of bits (b)")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.title("Fig.4-style: bits vs sentence length (train=10016)")
    plt.tight_layout()
    plt.show()
    
    # ----------------------------
    # Figure 5: cumulative bits vs number of texts
    # ----------------------------
    # ✅ 10016이니까 논문 느낌으로 더 촘촘히도 가능
    counts = [200, 400, 600, 800, 1000, 2000, 5000, 10016]
    counts = [c for c in counts if c <= len(rows)]
    
    
    y2_huff = [cumulative_kb("huff_bcc", n) for n in counts]
    y2_bit7 = [cumulative_kb("bit7_bcc", n) for n in counts]
    y2_ours = [cumulative_kb("ours_bcc", n) for n in counts]
    
    plt.figure(figsize=(7,4.5))
    plt.plot(counts, y2_huff, marker="o", label="Huffman + BCC")
    plt.plot(counts, y2_bit7, marker="^", label="Bit7 + BCC")
    plt.plot(counts, y2_ours, marker="*", label="Our proposed cognitive SC")
    plt.xlabel("Number of texts")
    plt.ylabel("Number of bits (kb)")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.title("Fig.5-style: cumulative bits vs number of texts (train=10016)")
    plt.tight_layout()
    plt.show()
    
    # ----------------------------
    # Quick print: 평균 절감률
    # ----------------------------
    avg_huff = float(np.mean([r["huff_bcc"] for r in rows]))
    avg_bit7 = float(np.mean([r["bit7_bcc"] for r in rows]))
    avg_ours = float(np.mean([r["ours_bcc"] for r in rows]))
    
    print("\n=== Average transmitted bits per text ===")
    print(f"Huffman+BCC: {avg_huff:.1f} bits")
    print(f"Bit7+BCC   : {avg_bit7:.1f} bits")
    print(f"Ours+BCC   : {avg_ours:.1f} bits")
    
    print("\n=== Reduction vs baselines ===")
    print(f"vs Huffman: {100*(1-avg_ours/avg_huff):.1f}%")
    print(f"vs Bit7   : {100*(1-avg_ours/avg_bit7):.1f}%")
    
    # ----------------------------
    # Health check: ours가 0이 너무 많은지
    # ----------------------------
    zero_ours = sum(1 for r in rows if r["ours_bcc"] == 0)
    print("\n=== Health check ===")
    print(f"ours_bcc==0: {zero_ours}/{len(rows)} ({100*zero_ours/len(rows):.2f}%)")
    
    
    
    import os, json, random, math, re
    import numpy as np
    import matplotlib.pyplot as plt
    import torch
    from collections import Counter
    
    # -------------------------
    # Config
    # -------------------------
    BASE_DIR = args.base_dir
    PAIRS_PATH      = os.path.join(BASE_DIR, "pairs_train_10016.json")
    ABSTR_SSC_PATH  = os.path.join(BASE_DIR, "semantic_symbol_abstraction_ssc_train_10016.json")
    KG_SSC_PATH     = os.path.join(BASE_DIR, "kg_triples_ssc_train_10016.json")
    T5_DIR          = os.path.join(BASE_DIR, "t5_kg2text_pt")
    
    assert os.path.exists(PAIRS_PATH), PAIRS_PATH
    assert os.path.exists(ABSTR_SSC_PATH), ABSTR_SSC_PATH
    assert os.path.exists(KG_SSC_PATH), KG_SSC_PATH
    assert os.path.exists(T5_DIR), T5_DIR
    
    REP = 3
    P_LIST = [0.0, 0.05, 0.10, 0.15, 0.20]
    N_SAMPLES = 200               # 120~500 추천
    FILTER_EMPTY_OURS = True      # ours가 empty인 샘플 제외(공정성/안정성 ↑)
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device)
    
    # -------------------------
    # Load data
    # -------------------------
    with open(PAIRS_PATH, "r", encoding="utf-8") as f:
        pairs = json.load(f)
    
    with open(ABSTR_SSC_PATH, "r", encoding="utf-8") as f:
        abstr = json.load(f)
    
    with open(KG_SSC_PATH, "r", encoding="utf-8") as f:
        kg_ssc = json.load(f)
    
    
    pairs_by_idx = {to_int_idx(ex.get("idx", i)): ex for i, ex in enumerate(pairs)}
    abstr_by_idx = {to_int_idx(ex.get("idx")): ex for ex in abstr if "idx" in ex}
    
    L = len(kg_ssc[0]["bits"])
    print("SSC bits per triple:", L)
    
    # KG codebook (for correction)
    KG_CODES = np.array([it["bits"] for it in kg_ssc], dtype=np.int8)
    bits2triple = {}
    for it in kg_ssc:
        tri = it.get("triple")
        if not tri:
            # fallback for older format
            tri = [it.get("h"), it.get("r"), it.get("t")]
        bits2triple[tuple(it["bits"])] = tri
    
    # -------------------------
    # T5 KG2Text
    # (평가 셀과 동일: paper-style linearize)
    # -------------------------
    from transformers import T5TokenizerFast, T5ForConditionalGeneration
    t5_tok = T5TokenizerFast.from_pretrained(T5_DIR)
    t5 = T5ForConditionalGeneration.from_pretrained(T5_DIR).to(device)
    t5.eval()
    
    MAX_SRC_LEN = 256
    
    
    
    @torch.no_grad()
    
    # -------------------------
    # Channel: BSC + repetition
    # -------------------------
    
    
    
    # correction: nearest neighbor in KG codebook (Hamming min)
    
    # -------------------------
    # Baselines: Bit7 + Huffman
    # -------------------------
    
    
    
    all_text = "".join([ex["text"] for ex in pairs])
    huff_code = build_huffman_codebook(all_text)
    
    
    trie = HuffTrie()
    for ch,code in huff_code.items():
        trie.add(ch,code)
    
    
    
    
    
    # -------------------------
    # OURS: (semantic_symbols_ssc bits) -> channel -> correction -> triples -> T5
    # -------------------------
    
    # -------------------------
    # Sentence similarity embeddings (cosine)
    # -------------------------
    from sentence_transformers import SentenceTransformer
    emb_model = SentenceTransformer("all-MiniLM-L6-v2", device=device)
    
    
    
    # -------------------------
    # BLEU-1..4 (stable)
    # -------------------------
    
    
    # -------------------------
    # Sample selection (공정하게: ours가 비어있는 샘플 제외 옵션)
    # -------------------------
    random.seed(7)
    all_idxs = [to_int_idx(ex.get("idx", i)) for i, ex in enumerate(pairs)]
    
    if FILTER_EMPTY_OURS:
        valid_idxs = [idx for idx in all_idxs if abstr_by_idx.get(idx, {}).get("semantic_symbols_ssc")]
        print("valid (non-empty ours):", len(valid_idxs), "/", len(all_idxs))
    else:
        valid_idxs = all_idxs
    
    eval_idxs = random.sample(valid_idxs, min(N_SAMPLES, len(valid_idxs)))
    eval_samples = [pairs_by_idx[idx] for idx in eval_idxs]
    
    # -------------------------
    # Run sweep
    # -------------------------
    sim_curve = {"huff":[], "bit7":[], "ours":[]}
    bleu_curve = {"huff":[[],[],[],[]], "bit7":[[],[],[],[]], "ours":[[],[],[],[]]}
    empty_rates = []
    
    
    for p in P_LIST:
        (s_h, s_b, s_o), bh, bb, bo, er = run_one_p(p)
        sim_curve["huff"].append(s_h)
        sim_curve["bit7"].append(s_b)
        sim_curve["ours"].append(s_o)
        for k in range(4):
            bleu_curve["huff"][k].append(bh[k])
            bleu_curve["bit7"][k].append(bb[k])
            bleu_curve["ours"][k].append(bo[k])
        empty_rates.append(er)
        print(f"p={p:.2f} | ours empty rate={er:.2%} | sim(ours)={s_o:.4f}")
    
    print("\nDone sweep.")
    
    # -------------------------
    # Plot Fig.6
    # -------------------------
    plt.figure(figsize=(7,4.5))
    plt.plot(P_LIST, sim_curve["huff"], marker="o", label="Huffman + BCC")
    plt.plot(P_LIST, sim_curve["bit7"], marker="^", label="Bit7 + BCC")
    plt.plot(P_LIST, sim_curve["ours"], marker="*", label="Our proposed cognitive SC")
    plt.xlabel("BSC wrong parameter p")
    plt.ylabel("Semantic similarity score (cosine)")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.title("Fig.6-style: Semantic similarity vs p (train=10016)")
    plt.tight_layout()
    plt.show()
    
    # -------------------------
    # Plot Fig.7 (BLEU-1..4 in 2x2)
    # -------------------------
    titles = ["BLEU-1", "BLEU-2", "BLEU-3", "BLEU-4"]
    plt.figure(figsize=(10,7.5))
    for i in range(4):
        ax = plt.subplot(2,2,i+1)
        ax.plot(P_LIST, bleu_curve["huff"][i], marker="o", label="Huffman + BCC")
        ax.plot(P_LIST, bleu_curve["bit7"][i], marker="^", label="Bit7 + BCC")
        ax.plot(P_LIST, bleu_curve["ours"][i], marker="*", label="Our proposed cognitive SC")
        ax.set_title(titles[i])
        ax.set_xlabel("BSC wrong parameter p")
        ax.set_ylabel("BLEU score")
        ax.grid(True, alpha=0.3)
        if i == 1:
            ax.legend(loc="best")
    plt.tight_layout()
    plt.show()
    
    # -------------------------
    # Health check: empty output rate
    # -------------------------
    plt.figure(figsize=(6.5,3.8))
    plt.plot(P_LIST, empty_rates, marker="o")
    plt.xlabel("BSC wrong parameter p")
    plt.ylabel("Ours empty output rate")
    plt.grid(True, alpha=0.3)
    plt.title("Health check: Ours empty outputs vs p")
    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--base_dir', type=str, default='webnlg_kg_text2kg_1000', help='Output directory')
    args = p.parse_args()
    main()
